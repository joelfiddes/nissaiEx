NISSAI / SANGVOR GEO PACKAGE - September 2026 campaign
Generated 2026-08-27. WGS84 (EPSG:4326), decimal degrees, elevations in metres a.s.l.

FILES
  nissai_2026.gpx      Waypoints for handheld GPS (Garmin etc.) and QGIS
  nissai_2026.kml      Google Earth / Google Maps, grouped and styled by type
  nissai_2026.geojson  QGIS / web mapping, elevation carried as Z
  nissai_2026.csv      Plain table for any other use

CONTENTS (23 points)
  8  stakes    NI 1-25 .. NI 7-25 plus accumulation stake NS8-24
  1  station   AWS Nissai (WP51)
  1  logger    WP100 Geoprecision M-Log5W-Rock
 13  loggers   SLF BLE ground temperature network

STATUS FIELD
  target      Stake position as left Sep 2025 - this is what to navigate to in 2026
  active      Expected working; read out this visit
  never_read  Installed 2021, never yet downloaded (WP54, 4616 m)
  suspended   DO NOT ACCESS - unstable block slope (WP44, WP47, WP48)
  lost        Confirmed lost; do not search (WP58 2024, WP63 2023)

CAVEATS
  - Stake positions are where stakes were left in Sep 2025. Ice flow will have moved
    them; treat as search origins, not fixed points, and record a new waypoint at each.
  - Elevations are GPS-derived. NI 6-25 elevation is suspect: 4343 m (2025) vs 4383 m
    (2024) at a near-identical position. Re-survey.
  - No terrain or imagery basemap is included - load these over your own basemap.
